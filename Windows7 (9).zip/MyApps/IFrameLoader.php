<link rel="stylesheet" href="https://unpkg.com/7.css">
<body>
<input list="browsers" name="browser" id="browser" style="width:50%;" placeholder="Enter URL here..." value="about:tutorial">
<datalist id="browsers">
  <option value="https://tileman.io/"> Tileman.IO </option>
  <option value="https://territorial.io/"> Territorial.IO </option>
  <option value="https://bing.com/"> Bing.COM </option>
  <option value="https://onlinelinux.mkcodes.repl.co/"> OnlineLinux.mkcodes.repl.co </option> <!-- DEVELOPER used STACKOVERFLOW! -->
  <option value="https://inflopnito.com/"> Inflopnito [ For other websites that don't work ] </option>
</datalist><button type="button" onclick="document.getElementById('ublockres').src=document.getElementById('browser').value"> load webpage </button>
<iframe id="ublockres" style="width:100%;height:100%;"></iframe>
<script>
    document.getElementById("ublockres").innerHTML="<h1>Welcome to IFrame Ublock</h1><p>By @sdf64 [ mkcodes ] </p> <br/> <p> This is a simple tool that unblocks most sites. </p>"
</script>
</body>