<!--XSS WARNING: DO NOT ADD ANY APPS TO THIS UNTIL IM DONE THERE IS RISK OF XSS-->
3<button type="button" onclick="parent.InstallApp('Bing', 'https://bing.com')"> Install Bing</button>