
<pre contenteditable="true">Welcome to Wordpad. <br/> Just copy paste anything into this div, it'll automatically get formatted. </pre>
<!-- TODO implement saeve/open -->