<?php
die("Abandoned project, this is a code dump");
?>
<link rel="stylesheet" href="https://unpkg.com/7.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.15.0/ace.js" integrity="sha512-vgArOyW+sdp69qm3025hO1uoxhMZ7rzc2NZbaC/0eUD92rYIx4YSI/NdQ1+oINXb8tXoFQJyQqpfV9KxoPGuCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<style>
  *{white-space: pre-wrap;
}
</style>
<script>

function readFile(file) {
  return new Promise((resolve, reject) => {
    let fr = new FileReader();
    fr.onload = x=> resolve(fr.result);
    fr.readAsText(file);
})}
function savelocal() {
         const link = document.createElement("a");
         const content = ace.edit("msg").getValue();
         const file = new Blob([content], { type: 'text/plain' });
         link.href = URL.createObjectURL(file);
         link.download = "rename_this_file";
         link.click();
         URL.revokeObjectURL(link.href);
}
async function read(input) {
  document.getElementById("msg").innerHTML = await readFile(input.files[0]);
  saveas = input.files[0];
  redefineAce();
  // document.getElementById("tmpdiv").style.display = "none";
  document.getElementById("tmpdiv").innerHTML = "<button type='button' onclick='savelocal();'>Save</button>";
}
</script>
<div id="tmpdiv"><input type="file" onchange="read(this)"/> <input type="textbox" placeholder="Enter code language e.g. 'javascript'" id="lang" /></div>

<pre id="msg" style="width:100%;height:100%;outline:1px solid blue;" contenteditable></pre>
<script>

function redefineAce() {
  ace.edit("msg", {
      mode: "ace/mode/"+document.getElementById("lang"),
      selectionStyle: "text"
  })
}

</script>