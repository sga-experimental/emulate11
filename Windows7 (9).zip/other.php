<script>location.href=prompt("Enter the link-to-app URL [ must support iFrame ]","")</script>
<!-- if u delete this file i can't load apps becaue im on older verison lol -->
<!-- will be deleted when im done wit da session -->
<script>parent.notify("You're on an old version of W11. Please upgrade.")</script>